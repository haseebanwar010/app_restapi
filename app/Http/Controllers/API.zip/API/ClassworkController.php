<?php

namespace App\Http\Controllers\API;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Http\Request; 
use App\Http\Controllers\Controller; 
use Illuminate\Support\Facades\Auth; 
use Illuminate\Support\Facades\DB;
use Validator;
use CommonHelper;


class ClassworkController extends Controller
{
    private $response=array();

    public function __construct(Request $request)
    {
        $token=CommonHelper::token_authentication();
        if($request->hasHeader('Authoraization'))
        {
            if($token==$request->header('Authoraization'))
            {
            }
            else
            {
                $this->response=array
                (
                    'status' => 'error',
                    'message' => 'Invalid authentication token!',
                    'data' => ''
                );
            }
        }
        else
        {
            $this->response=array
            (
                'status' => 'error',
                'message' => 'Only authenticated requests are allowed!',
                'data' => ''
            );
        }
    }


    public function student_class_activity(Request $request)
    {
        if(!empty($this->response))
        {
            return response()->json($this->response, 400);
        }
        else
        {
            if($request->input('api_token') && $request->input('api_token')!='')
            {
                if($request->input('content_type') && $request->input('content_type')!='')
                {
                    $user = DB::table('users')->where('api_token', $request->input('api_token'))->where('deleted_at', '=', '0')->first();
                    if($user)
                    {
                        ////////////////////////////////////////////////////////////////////////
                        $school_id = $user->school_id;
                        $student_id = $user->id;
                        $current_date = date('Y-m-d');
                        
                        DB::enableQueryLog();
                        $response=DB::table('assignments')
                        ->join('classes', 'assignments.class_id', '=', 'classes.id', 'left')
                        ->join('subjects', 'assignments.subject_id', '=', 'subjects.id', 'left')
                        ->join('users', 'assignments.uploaded_by', '=', 'users.id', 'left')
                        ->select('assignments.*', 'classes.name as class_name', 'subjects.name as subject_name', 'users.name as teacher_name', 'users.id as teacher_id', 'users.avatar')
                        ->whereIn('assignments.student_ids',[$student_id])
                        ->where('assignments.school_id',$school_id)
                        ->where('assignments.deleted_status',0)
                        ->orderBy('assignments.created_at','desc');
                        if($request->input('date') && $request->input('date')!='')
                        {
                            if($request->input('subject_id') && $request->input('subject_id')!='')
                            {
                                if($request->input('content_type')=='Assignment' || $request->input('content_type')=='assignment')
                                {
                                    $response=$response->where('assignments.content_type','Assignment')->where('assignments.published_date','=',$request->input('date'))->where('assignments.subject_id','=',$request->input('subject_id'))->get()->all();
                                }
                                else
                                {
                                    $response=$response->where('assignments.content_type','Homework')->where('assignments.published_date','=',$request->input('date'))->where('assignments.subject_id','=',$request->input('subject_id'))->get()->all();
                                }
                            }
                            else
                            {
                                if($request->input('content_type')=='Assignment' || $request->input('content_type')=='assignment')
                                {
                                    $response=$response->where('assignments.content_type','Assignment')->where('assignments.published_date','=',$request->input('date'))->get()->all();
                                }
                                else
                                {
                                    $response=$response->where('assignments.content_type','Homework')->where('assignments.published_date','=',$request->input('date'))->get()->all();
                                }
                            }
                            
                        }
                        else
                        {
                            if($request->input('subject_id') && $request->input('subject_id')!='')
                            {
                                if($request->input('content_type')=='Assignment' || $request->input('content_type')=='assignment')
                                {
                                    $response=$response->where('assignments.content_type','Assignment')->where('assignments.published_date','<=',$current_date)->where('assignments.subject_id','=',$request->input('subject_id'))->get()->all();
                                }
                                else
                                {
                                    $response=$response->where('assignments.content_type','Homework')->where('assignments.published_date','<=',$current_date)->where('assignments.subject_id','=',$request->input('subject_id'))->get()->all();
                                }
                            }
                            else
                            {
                                if($request->input('content_type')=='Assignment' || $request->input('content_type')=='assignment')
                                {
                                    $response=$response->where('assignments.content_type','Assignment')->where('assignments.published_date','<=',$current_date)->get()->all();
                                }
                                else
                                {
                                    $response=$response->where('assignments.content_type','Homework')->where('assignments.published_date','<=',$current_date)->get()->all();
                                }
                            }
                            
                        }
                        
                        
                        
                        
                        
                        
                        foreach ($response as $i => $res)
                        {
                            $re=DB::table('submit_material')->where('material_id',$res->id)->where('student_id',$student_id)->where('deleted_status',0)->get()->all();
                            
                            if(sizeof($re) > 0 )
                            {
                                $res->status = "Submitted";
                                if($re[0]->obtained_marks == "")
                                {
                                    $res->obtained_marks = "Waiting";
                                }
                                else
                                {
                                    $res->obtained_marks = $re[0]->obtained_marks;
                                } 
                            }
                            else
                            {
                                $res->status = "Due";
                                $res->obtained_marks = "Submit Your Assignment First";
                            }
                            
                            $response[$i]->files = explode(",", $response[$i]->files);
                            $response[$i]->filesurl = explode(",", $response[$i]->filesurl);
                            $response[$i]->file_names = explode(",", $response[$i]->file_names);
                            $response[$i]->thumbnail_links = explode(",", $response[$i]->thumbnail_links);
                        }
                        if(sizeof($response) > 0)
                        {
                            $this->response=array
                            (
                                'status' => 'success',
                                'message' => $request->input('content_type').' fetch successfully!',
                                'data' => $response
                            );
                            return response()->json($this->response, 200);
                            die;
                        }
                        else
                        {
                            $this->response=array
                            (
                                'status' => 'success',
                                'message' => 'No '.$request->input('content_type').' found!',
                                'data' => ''
                            );
                            return response()->json($this->response, 200);
                            die;
                        }
                        ////////////////////////////////////////////////////////////////////////
                    }
                    else
                    {
                        $this->response=array
                        (
                            'status' => 'error',
                            'message' => 'Invalid user!',
                            'data' => ''
                        );
                        return response()->json($this->response, 400);
                        die;
                    }
                }
                else
                {
                    $this->response=array
                    (
                        'status' => 'error',
                        'message' => 'Content type is required!',
                        'data' => ''
                    );
                    return response()->json($this->response, 400);
                    die;
                }
            }
            else
            {
                $this->response=array
                (
                    'status' => 'error',
                    'message' => 'Invalid user!',
                    'data' => ''
                );
                return response()->json($this->response, 400);
                die;
            }
        }
    }
    
    
    
    
    
}
