<?php

namespace App\Http\Controllers\API;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Http\Request; 
use App\Http\Controllers\Controller; 
use Illuminate\Support\Facades\Auth; 
use Illuminate\Support\Facades\DB;
use Validator;
use CommonHelper;


class StudymaterialController extends Controller
{
    private $response=array();
 
    public function __construct(Request $request)
    {
        $token=CommonHelper::token_authentication();
        if($request->hasHeader('Authoraization'))
        {
            if($token==$request->header('Authoraization'))
            {
            }
            else
            {
                $this->response=array
                (
                    'status' => 'error',
                    'message' => 'Invalid authentication token!',
                    'data' => ''
                );
            }
        }
        else
        {
            $this->response=array
            (
                'status' => 'error',
                'message' => 'Only authenticated requests are allowed!',
                'data' => ''
            );
        }
    }

    //Parent side api for all childs
    public function parent_studymaterial(Request $request)
    {
        if(!empty($this->response))
        {
            return response()->json($this->response, 400);
        }
        else
        {
            if($request->input('api_token') && $request->input('api_token')!='')
            {
                $user = DB::table('users')->where('api_token', $request->input('api_token'))->whereIn('role_id', [2,3,4])->where('deleted_at', '=', '0')->first();
    
                if($user)
                {
                    $students=DB::table('student_guardians')->select('student_id')->where('guardian_id',$user->id)->whereNull('deleted_at')->get()->all();
                    $academic_year=DB::table('academic_years')->select('id')->where('school_id',$user->school_id)->where('is_active','Y')->whereNull('deleted_at')->first();
                    $student_record=array();
                    
                    if(sizeof($students) > 0)
                    {
                        foreach($students as $stu)
                        {
                            $student_rec = DB::select("SELECT s.class_id, s.batch_id, s.subject_group_id, sh_batches.name as batch_name FROM sh_students_$user->school_id s left JOIN sh_batches ON sh_batches.id = s.batch_id WHERE  s.id='$stu->student_id' ");

                            $student_rec=$student_rec[0];
                            if($student_rec->subject_group_id != "" && $student_rec->subject_group_id != null && $student_rec->subject_group_id != 0)
                            {
                                $subject_ids=DB::table('subject_groups')->select('subjects')->where('id',$student_rec->subject_group_id)->whereNull('deleted_at')->first()->subjects;
                                $subject_ids = array_map( 'trim', explode( ",",$subject_ids ) );
    
                                foreach($subject_ids as $key => $ids)
                                {
                                    $subject_ids[$key]=(int)$ids;
                                }
                                $current_date = date("Y-m-d");
                                // $current_date = '2021-03-05';
                               
                               DB::enableQueryLog();
                                $data=DB::table('study_material')
                                ->join('classes', 'study_material.class_id', '=', 'classes.id')
                                ->join('batches', 'study_material.batch_id', '=', 'batches.id','left')
                                ->join('subjects', 'study_material.subject_code', '=', 'subjects.code', 'left')
                                ->join('users', 'study_material.uploaded_by', '=', 'users.id', 'left')
                                ->selectRaw('sh_users.id as student_id,sh_users.name,sh_users.avatar,sh_study_material.*,sh_classes.name as class_name,sh_batches.name as batch_name,sh_subjects.name as subject_name,sh_users.name,DATE_FORMAT("sh_study_material.uploaded_at","%d/%m/%Y") as uploaded_time')
                                ->where('study_material.delete_status', 0)
                                ->where('study_material.school_id', $user->school_id)
                                ->where('study_material.uploaded_at', $current_date)
                                ->where('classes.academic_year_id', $academic_year->id)
                                ->where('study_material.class_id', $student_rec->class_id)
                                ->whereIn('study_material.batch_id',[$student_rec->batch_id])
                                ->whereIn('study_material.subject_id',$subject_ids)
                                ->groupBy('study_material.id')->orderBy('study_material.uploaded_at','desc')
                                ->get()->all();
                                
    
                                if(sizeof($data) > 0)
                                {
                                    foreach($data as $key => $rec)
                                    {
                                        $data[$key]->files=explode(',',$rec->files);
                                        $data[$key]->filesurl=explode(',',$rec->filesurl);
                                        $data[$key]->file_names=explode(',',$rec->file_names);
                                        $data[$key]->fileids=explode(',',$rec->fileids);
                                        $data[$key]->thumbnail_links=explode(',',$rec->thumbnail_links);
                                        $data[$key]->icon_links=explode(',',$rec->icon_links);
                                    }
                                    $student_record[]=$data;
                                }
                                
                            }
                            // else
                            // {
                            //     $this->response=array
                            //     (
                            //         'status' => 'error',
                            //         'message' => 'Subject groups are not assigned!',
                            //         'data' => ''
                            //     );
                            //     return response()->json($this->response, 400);
                            //     die;
                            // }
                        }
                        
                        if($student_record && sizeof($student_record) > 0)
                        {
                            $this->response=array
                            (
                                'status' => 'success',
                                'message' => 'Studymaterial fetch successfully!',
                                'data' => $student_record
                            );
                            return response()->json($this->response, 200);
                            die;
                        }
                        else
                        {
                            $this->response=array
                            (
                                'status' => 'success',
                                'message' => 'No study material found!',
                                'data' => ''
                            );
                            return response()->json($this->response, 200);
                            die;
                        }
                    }
                    else
                    {
                        $this->response=array
                        (
                            'status' => 'error',
                            'message' => 'No childs found!',
                            'data' => ''
                        );
                        return response()->json($this->response, 400);
                        die;
                    }
                }
                else
                {
                    $this->response=array
                    (
                        'status' => 'error',
                        'message' => 'Invalid user!',
                        'data' => ''
                    );
                    return response()->json($this->response, 400);
                    die;
                }
                
                
            }
            else
            {
                $this->response=array
                (
                    'status' => 'error',
                    'message' => 'Invalid user!',
                    'data' => ''
                );
            }
        }
    }
  
    
  
    
    public function student_studymaterial(Request $request)
    {
        if(!empty($this->response))
        {
            return response()->json($this->response, 400);
        }
        else
        {
            if($request->input('api_token') && $request->input('api_token')!='')
            {
                $user = DB::table('users')->where('api_token', $request->input('api_token'))->whereIn('role_id', [2,3,4])->where('deleted_at', '=', '0')->first();
    
                if($user)
                {
                    $academic_year=DB::table('academic_years')->select('id')->where('school_id',$user->school_id)->where('is_active','Y')->whereNull('deleted_at')->first();
                    $student = DB::select("SELECT s.class_id, s.batch_id, s.subject_group_id, sh_batches.name as batch_name FROM sh_students_$user->school_id s left JOIN sh_batches ON sh_batches.id = s.batch_id WHERE  s.id='$user->id' ");
                    if(sizeof($student) > 0)
                    {
                        $student=$student[0];
                        if($student->subject_group_id != "" && $student->subject_group_id != null && $student->subject_group_id != 0)
                        {
                            
                            $subject_ids=DB::table('subject_groups')->select('subjects')->where('id',$student->subject_group_id)->whereNull('deleted_at')->first()->subjects;

                            // $subject_ids=explode(',',$subject_ids); 
                            $subject_ids = array_map( 'trim', explode( ",",$subject_ids ) );

                            foreach($subject_ids as $key => $ids)
                            {
                                $subject_ids[$key]=(int)$ids;
                                
                            }
                            $current_date = date("Y-m-d");
                            // $current_date = '2021-03-05';
                           
                            $data=DB::table('study_material')
                            ->join('classes', 'study_material.class_id', '=', 'classes.id')
                            ->join('batches', 'study_material.batch_id', '=', 'batches.id','left')
                            ->join('subjects', 'study_material.subject_code', '=', 'subjects.code', 'left')
                            ->join('users', 'study_material.uploaded_by', '=', 'users.id', 'left')
                            ->selectRaw('sh_study_material.*,sh_classes.name as class_name,sh_batches.name as batch_name,sh_subjects.name as subject_name,sh_users.name,DATE_FORMAT("sh_study_material.uploaded_at","%d/%m/%Y") as uploaded_time')
                            ->where('study_material.delete_status', 0)
                            ->where('study_material.school_id', $user->school_id)
                            ->where('study_material.uploaded_at', $current_date)
                            ->where('classes.academic_year_id', $academic_year->id)
                            ->where('study_material.class_id', $student->class_id)
                            ->whereIn('study_material.batch_id',[$student->batch_id])
                            ->whereIn('study_material.subject_id',$subject_ids)
                            ->groupBy('study_material.id')->orderBy('study_material.uploaded_at','desc')
                            ->get()->all();

                            foreach($data as $key => $rec)
                            {
                                $data[$key]->files=explode(',',$rec->files);
                                $data[$key]->filesurl=explode(',',$rec->filesurl);
                                $data[$key]->file_names=explode(',',$rec->file_names);
                                $data[$key]->fileids=explode(',',$rec->fileids);
                                $data[$key]->thumbnail_links=explode(',',$rec->thumbnail_links);
                                $data[$key]->icon_links=explode(',',$rec->icon_links);
                            }

                            if($data && sizeof($data) > 0)
                            {
                                $this->response=array
                                (
                                    'status' => 'success',
                                    'message' => 'Studymaterial fetch successfully!',
                                    'data' => $data
                                );
                                return response()->json($this->response, 200);
                                die;
                            }
                            else
                            {
                                $this->response=array
                                (
                                    'status' => 'success',
                                    'message' => 'No study material found!',
                                    'data' => ''
                                );
                                return response()->json($this->response, 200);
                                die;
                            }
                            
                            
                        }
                        else
                        {
                            $this->response=array
                            (
                                'status' => 'error',
                                'message' => 'Subject groups are not assigned!',
                                'data' => ''
                            );
                            return response()->json($this->response, 400);
                            die;
                        }
                    }
                }
                else
                {
                    $this->response=array
                    (
                        'status' => 'error',
                        'message' => 'Invalid user!',
                        'data' => ''
                    );
                    return response()->json($this->response, 400);
                    die;
                }
                
                
            }
            else
            {
                $this->response=array
                (
                    'status' => 'error',
                    'message' => 'Invalid user!',
                    'data' => ''
                );
            }
        }
    }
    
    
    
    
    
}
