<?php

namespace App\Http\Controllers\API;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Http\Request; 
use App\Http\Controllers\Controller; 
use Illuminate\Support\Facades\Auth; 
use Illuminate\Support\Facades\DB;
use Validator;
use CommonHelper;


class AttendanceController extends Controller
{
    private $response=array();

    public function __construct(Request $request)
    {
        $token=CommonHelper::token_authentication();
        if($request->hasHeader('Authoraization'))
        {
            if($token==$request->header('Authoraization'))
            {
            }
            else
            {
                $this->response=array
                (
                    'status' => 'error',
                    'message' => 'Invalid authentication token!',
                    'data' => ''
                );
            }
        }
        else
        {
            $this->response=array
            (
                'status' => 'error',
                'message' => 'Only authenticated requests are allowed!',
                'data' => ''
            );
        }
    }

 
    public function all_studentsAttendance(Request $request)
    {
        if(!empty($this->response))
        {
            return response()->json($this->response, 400);
            die;
        }
        else
        {
            if($request->input('api_token') && $request->input('api_token')!='')
            {
                if($request->input('month') && $request->input('month')!='')
                {
                    if($request->input('month') >= 0 && $request->input('month') <=12)
                    {
                        $user = DB::table('users')->where('api_token', $request->input('api_token'))->where('deleted_at', '=', '0')->first();
                        if($user)
                        {
                            $students=DB::table('student_guardians')->select('student_id')->where('guardian_id',$user->id)->whereNull('deleted_at')->get()->all();
                        
                            if(sizeof($students) > 0)
                            {
                                foreach($students as $key => $ids)
                                {
                                    $students[$key]=(int)$ids->student_id;
                                }
                                
                                $academic_year=DB::table('academic_years')->select('id')->where('school_id',$user->school_id)->where('is_active','Y')->whereNull('deleted_at')->first();
                                $month = $request->input('month');
                                $year=date("Y");
                                // $year=2020;
                                $day=date("d");
                                $current_date=$year.'-'.$month.'-'.$day;
                                
                                $start_date=date("Y-m-01", strtotime($current_date));
                                $end_date=date("Y-m-t", strtotime($current_date));
                                
                                $response=DB::table('attendance')
                                ->join('users', 'attendance.user_id', '=', 'users.id', 'left')
                                ->select('attendance.id', 'users.name', 'users.avatar', 'attendance.date','attendance.status')
                                ->whereIn('attendance.user_id',$students)
                                ->where('attendance.school_id',$user->school_id)
                                ->whereBetween('attendance.date', [$start_date,$end_date])
                                ->whereNULL('attendance.deleted_at')
                                ->where('users.deleted_at',0)
                                ->get()->all();
                                
                                if($response)
                                {
                                    foreach($response as $key => $res)
                                    {
                                        $response[$key]->day=date("d", strtotime($res->date));
                                        $response[$key]->today=date("l", strtotime($res->date));
                                        $response[$key]->month=date("F", strtotime($res->date));
                                    }
                                    
                                    $this->response=array
                                    (
                                        'status' => 'success',
                                        'message' => 'Attendance fetch successfully!',
                                        'data' => $response
                                    );
                                    return response()->json($this->response, 200);
                                    die;
                                }
                                else
                                {
                                    $this->response=array
                                    (
                                        'status' => 'success',
                                        'message' => 'No attendance found!',
                                        'data' => ''
                                    );
                                    return response()->json($this->response, 200);
                                    die;
                                }
                            }
                            
                        }
                        else
                        {
                            $this->response=array
                            (
                                'status' => 'error',
                                'message' => 'Invalid user!',
                                'data' => ''
                            );
                            return response()->json($this->response, 400);
                            die;
                        }
                    }
                    else
                    {
                        $this->response=array
                        (
                            'status' => 'error',
                            'message' => 'Please select valid month!',
                            'data' => ''
                        );
                        return response()->json($this->response, 400);
                        die;
                    }
                }
                else
                {
                    $this->response=array
                    (
                        'status' => 'error',
                        'message' => 'Month is required!!',
                        'data' => ''
                    );
                    return response()->json($this->response, 400);
                    die;
                }
            }
            else
            {
                $this->response=array
                (
                    'status' => 'error',
                    'message' => 'Invalid user!',
                    'data' => ''
                );
                return response()->json($this->response, 400);
                die;
            }
        }
    }
    
    
    
    //sibgle child attendence
    public function student_attendance(Request $request)
    {
        if(!empty($this->response))
        {
            return response()->json($this->response, 400);
            die;
        }
        else
        {
            if($request->input('api_token') && $request->input('api_token')!='')
            {
                if($request->input('month') && $request->input('month')!='')
                {
                    if($request->input('month') >= 0 && $request->input('month') <=12)
                    {
                        $user = DB::table('users')->where('api_token', $request->input('api_token'))->where('deleted_at', '=', '0')->first();
                        if($user)
                        {
                            $academic_year=DB::table('academic_years')->select('id')->where('school_id',$user->school_id)->where('is_active','Y')->whereNull('deleted_at')->first();
                            $month = $request->input('month');
                            $year=date("Y");
                            // $year=2020;
                            $day=date("d");
                            $current_date=$year.'-'.$month.'-'.$day;
                            
                            $start_date=date("Y-m-01", strtotime($current_date));
                            $end_date=date("Y-m-t", strtotime($current_date));
                            
                            $response=DB::table('attendance')
                            ->select('id','date','status')
                            ->where('user_id',$user->id)
                            ->where('school_id',$user->school_id)
                            ->whereBetween('date', [$start_date,$end_date])
                            ->whereNULL('deleted_at')
                            ->get()->all();
                            
                            if($response)
                            {
                                foreach($response as $key => $res)
                                {
                                    $response[$key]->day=date("d", strtotime($res->date));
                                    $response[$key]->today=date("l", strtotime($res->date));
                                    $response[$key]->month=date("F", strtotime($res->date));
                                }
                                
                                $this->response=array
                                (
                                    'status' => 'success',
                                    'message' => 'Attendance fetch successfully!',
                                    'data' => $response
                                );
                                return response()->json($this->response, 200);
                                die;
                            }
                            else
                            {
                                $this->response=array
                                (
                                    'status' => 'success',
                                    'message' => 'No attendance found!',
                                    'data' => ''
                                );
                                return response()->json($this->response, 200);
                                die;
                            }
                            
                        }
                        else
                        {
                            $this->response=array
                            (
                                'status' => 'error',
                                'message' => 'Invalid user!',
                                'data' => ''
                            );
                            return response()->json($this->response, 400);
                            die;
                        }
                    }
                    else
                    {
                        $this->response=array
                        (
                            'status' => 'error',
                            'message' => 'Please select valid month!',
                            'data' => ''
                        );
                        return response()->json($this->response, 400);
                        die;
                    }
                }
                else
                {
                    $this->response=array
                    (
                        'status' => 'error',
                        'message' => 'Month is required!!',
                        'data' => ''
                    );
                    return response()->json($this->response, 400);
                    die;
                }
            }
            else
            {
                $this->response=array
                (
                    'status' => 'error',
                    'message' => 'Invalid user!',
                    'data' => ''
                );
                return response()->json($this->response, 400);
                die;
            }
        }
    }
    
    
    
    
    
}
