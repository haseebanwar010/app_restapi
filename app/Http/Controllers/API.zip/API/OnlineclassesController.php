<?php

namespace App\Http\Controllers\API;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Http\Request; 
use App\Http\Controllers\Controller; 
use Illuminate\Support\Facades\Auth; 
use Illuminate\Support\Facades\DB;
use Validator;
use CommonHelper;


class OnlineclassesController extends Controller
{
    private $response=array();

    public function __construct(Request $request)
    {
        $token=CommonHelper::token_authentication();
        if($request->hasHeader('Authoraization'))
        {
            if($token==$request->header('Authoraization'))
            {
            }
            else
            {
                $this->response=array
                (
                    'status' => 'error',
                    'message' => 'Invalid authentication token!',
                    'data' => ''
                );
            }
        }
        else
        {
            $this->response=array
            (
                'status' => 'error',
                'message' => 'Only authenticated requests are allowed!',
                'data' => ''
            );
        }
    }


    public function get_online_classes(Request $request)
    {
        if(!empty($this->response))
        {
            return response()->json($this->response, 400);
        }
        else
        {
            if($request->input('api_token') && $request->input('api_token')!='')
            {
                $user = DB::table('users')->where('api_token', $request->input('api_token'))->whereIn('role_id', [2,3,4])->where('deleted_at', '=', '0')->first();
                if($user)
                {
                    $student_rec = DB::select("SELECT s.class_id, sh_classes.name as class_name, s.batch_id, sh_batches.name as batch_name, sh_users.name as student_name FROM sh_students_$user->school_id s left JOIN sh_users ON s.id = sh_users.id left JOIN sh_classes ON s.class_id = sh_classes.id left JOIN sh_batches ON sh_batches.id = s.batch_id WHERE s.id='$user->id' ");
                    
                    if(sizeof($student_rec) > 0)
                    {
                        $student_rec=$student_rec[0];
                        $data=DB::table('online_classes')
                        ->join('users', 'online_classes.started_by', '=', 'users.id')
                        ->select('online_classes.id', 'online_classes.class_name', 'online_classes.status', 'users.name as teacher_name')
                        ->where('online_classes.class_id',$student_rec->class_id)
                        ->where('online_classes.batch_id',$student_rec->batch_id)
                        ->where('online_classes.status','ongoing')
                        ->whereNull('online_classes.deleted_at')->first();
                        
                        if($data)
                        {
                            $this->response=array
                            (
                                'status' => 'success',
                                'message' => 'online class found successfully!',
                                'data' => $data
                            );
                            return response()->json($this->response, 200);
                        }
                        else
                        {
                            $this->response=array
                            (
                                'status' => 'success',
                                'message' => 'No online class found!',
                                'data' => ''
                            );
                            return response()->json($this->response, 200);
                        }
                    }
                    else
                    {
                        $this->response=array
                        (
                            'status' => 'error',
                            'message' => 'class or batch not found!',
                            'data' => ''
                        );
                        return response()->json($this->response, 404);
                    }
                    
                    
                    
                    // $class = $this->db->select('class_name,u.name as teacher')->from('sh_online_classes o')->join('sh_users u','u.id = o.started_by')->where('o.class_id', $student->class_id)->where('o.batch_id', $student->batch_id)->where('o.status', 'ongoing')->where('o.deleted_at is null')->get()->row();
                }
                else
                {
                    $this->response=array
                    (
                        'status' => 'error',
                        'message' => 'Invalid user!',
                        'data' => ''
                    );
                    return response()->json($this->response, 400);
                }
            }
            else
            {
                $this->response=array
                (
                    'status' => 'error',
                    'message' => 'Invalid user!',
                    'data' => ''
                );
                return response()->json($this->response, 400);
            }
        }
    }
    
    
    
    
    
}
